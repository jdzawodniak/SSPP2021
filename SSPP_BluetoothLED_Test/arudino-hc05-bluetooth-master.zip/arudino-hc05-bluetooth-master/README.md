# arudino-hc05-bluetooth
Here's how to use HC-05 Bluetooth Module with Arduino. And build Android App using MIT App Inventor to control devices connected over Bluetooth.
